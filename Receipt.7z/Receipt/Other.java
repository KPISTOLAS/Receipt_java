public class Other extends Item {
  

    public Other(String name, float price, int quontity, String details) {
        super(name, price, quontity, details);
    }
    
}
