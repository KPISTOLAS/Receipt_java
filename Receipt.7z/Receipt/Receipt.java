import java.util.ArrayList;
import java.util.Scanner;
public class Receipt{

 private ArrayList<Item>list;

    public Receipt(){
        list = new ArrayList<>();
    }

public void AddProduct(Item product ){
    list.add(product);
}

public void removeAllProducts() {
    list.clear();
}
public float calculateTotalPrice() {
    float total = 0;
    for (Item product : list) {
        total += product.calculateTotalPrice();
    }
    return total;
}

public  void displayReceipt() {
        System.out.println("");

        System.out.println("****************************");

        for (Item product : list ) {
            
            
            
            System.out.println("Name: " + product.getName());
            System.out.println("Price: " + product.getPrice());
            System.out.println("Quontity is :"+ product.getQuontity());
            System.out.println("Details is : "+ product.getdetails() );
            
            
        }
        System.out.println("****************************");
    }
 public static void main(String[] args) {
    
    Receipt cart = new  Receipt();

        try (Scanner myObj = new Scanner(System.in)) {
            System.out.println("Welcome to receipt app enter your items.");
            int an;
            int anF;
            int t2;
            

            String Inname;
            float Inprice;
             int Inquontity;
             String Indetails;

            do{
            do {
            /*Adding items  */
            
            do{
                System.out.println("Do you want Coffee  (0) or Soft drinks (1) or Juice (2) or or Snakes(3) Other (4)");
              t2 = myObj.nextInt(); 
            }while(!(t2==1||t2==0 ||t2==2  ||t2==3 ));
            
           switch (t2) {
            case 0:
                System.out.println("Enter name ");
                Inname= myObj.nextLine(); 
                System.out.println("Enter price ");
                Inprice= myObj.nextFloat();
                System.out.println("Enter quontity ");
                Inquontity= myObj.nextInt();
                System.out.println("Enter Details ");
                Indetails= myObj.nextLine();

                cart.AddProduct(new Coffee(Inname,Inprice, Inquontity , Indetails ));

                break;
            case 1:
                System.out.println("Enter name ");
                Inname= myObj.nextLine(); 
                System.out.println("Enter price ");
                Inprice= myObj.nextFloat();
                System.out.println("Enter quontity ");
                Inquontity= myObj.nextInt();
                System.out.println("Enter size ");
                Indetails= myObj.nextLine();

                cart.AddProduct(new SoftDrinks(Inname,Inprice, Inquontity , Indetails ));
                break;
            case 2:
                System.out.println("Enter name ");
                Inname= myObj.nextLine(); 
                System.out.println("Enter price ");
                Inprice= myObj.nextFloat();
                System.out.println("Enter quontity ");
                Inquontity= myObj.nextInt();
                System.out.println("Enter size ");
                Indetails= myObj.nextLine();

                cart.AddProduct(new Juice(Inname,Inprice, Inquontity , Indetails ));
                break;
             case 3:
                System.out.println("Enter name ");
                Inname= myObj.nextLine(); 
                System.out.println("Enter price ");
                Inprice= myObj.nextFloat();
                System.out.println("Enter quontity ");
                Inquontity= myObj.nextInt();
                System.out.println("Enter size ");
                Indetails= myObj.nextLine();
                cart.AddProduct(new Snakes(Inname,Inprice, Inquontity , Indetails ));

                default:
                System.out.println("Enter name ");
                Inname= myObj.nextLine(); 
                System.out.println("Enter price ");
                Inprice= myObj.nextFloat();
                System.out.println("Enter quontity ");
                Inquontity= myObj.nextInt();
                Indetails= "One size";

                cart.AddProduct(new Other(Inname,Inprice, Inquontity , Indetails ));
        }
          
            do{
                System.out.println("Do you want to continue (0) or to stop and print the receipt (1)");
              an = myObj.nextInt(); 
            }while(!(an==1|| an ==0 ));;
            
            }while(!(an==1));
            
            
            /*display receipt*/
            cart.displayReceipt();
              System.out.println("Tottal price is : "+cart.calculateTotalPrice());
            
            cart.removeAllProducts();

              do{
                System.out.println("Do you want to make another order (0) or to stop  (1)");
              anF = myObj.nextInt(); 
            }while(!(anF==1||anF==0));
            
            }while (!(anF==1));
        }

System.out.println("Thank you for using this app");

    }
}

