public  class Juice extends Item {


    public Juice(String name, float price, int quontity, String details) {
        super(name, price, quontity, details);
       
    }
    
}
