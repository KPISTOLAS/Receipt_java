public class SoftDrinks extends Item  {


    public SoftDrinks(String name, float price, int quontity, String details) {
        super(name, price, quontity, details);
        
    }
    
}
