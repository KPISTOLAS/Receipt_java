public abstract class  Item {
    private String name;
    private int quontity;
    private Float price;
    private String details;

    public Item (String name , float price , int quontity , String details){
this.name = name;
this.price = price;
this.quontity = quontity;
this.details=details;
}
     
public String getName(){
    return name;
}

public Float getPrice(){
    return price;
}

public int getQuontity(){
    return quontity;
}

public String getdetails(){
return details;
}

    public Float calculateTotalPrice(){
        return price*quontity;
        }

}
