public class Snakes extends Item {


    public Snakes(String name, float price, int quontity, String details) {
        super(name, price, quontity, details);
        
    }
    
}
