public  class Coffee extends Item {


    public Coffee(String name, float price, int quontity, String details) {
        super(name, price, quontity, details);
        
    }
    
}
